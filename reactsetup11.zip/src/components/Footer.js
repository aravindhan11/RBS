import React, { Component } from 'react';
import "bootstrap/dist/css/bootstrap.css"

export default class Footer extends Component {

    render() {
        return (
            <footer>
                <div>
                    @The Royal Bank of Scotland.All rights,save,expressly granted,are reserved.
                </div>
            </footer>

        );

    }

}