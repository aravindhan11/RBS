import React, { Component } from 'react';
import { Field, reduxForm } from 'redux-form';
import datepicker from './datepicker';
import TimeBlock from './TimeBlock';
import './form.scss'


const handleChange = (handler) => ({target: {files}}) =>
  handler(files.length ? {file: files[0], name: files[0].name} : {});


const FileInput = ({ 
  input: { value: omitValue, onChange, onBlur, ...inputProps }, 
  meta: omitMeta, 
  ...props 
}) => {
  return (
    <input className = "booking-attachment"
      onChange={handleChange(onChange)}
      onBlur={handleChange(onBlur)}
      type="file"
      accept='.docx'
      {...props.input}
      {...props}
    />
  );
};

export default class EnvBooking extends Component {

    constructor(props){
        super(props);

        this.state = {
            setDate:''
        }

        this.scheduleDate = this.scheduleDate.bind(this);
    }

    scheduleDate(Date){
        
        let setBsDate = Date.getFullYear()+"/"+(Date.getMonth()+1)+"/"+Date.getDate();
        console.log("hiss",setBsDate)
    }

    render() {
        console.log("its calling from parent")
            return (
                <form className = "border form-header1" onSubmit={this.props.handleSubmit}>
                    <h2>Shedule Environment</h2>
                    <div>
                        <label>First Name</label>
                        <div>
                            <Field name="firstName" component="input" type="text" placeholder="First Name" />
                        </div>
                    </div>
                    <div>
                        <label>Last Name</label>
                        <div>
                            <Field name="lastName" component="input" type="text" placeholder="Last Name" />
                        </div>
                    </div>
                    <div>
                        <label>Email</label>
                        <div>
                            <Field name="email" component="input" type="email" placeholder="Email" />
                        </div>
                    </div>
                    <div>
                        <label>Environment</label>
                        <div>
                            <Field name="DevEnvironment" component="select">
                                <option></option>
                                <option value="ff0000">Dev</option>
                                <option value="00ff00">SIT</option>
                                <option value="0000ff">NFT</option>
                            </Field>
                        </div>
                    </div>
                    <div>
                        <label>Client</label>
                        <div>
                            <Field name="Client" component="select">
                                <option></option>
                                <option value="Open Banking">Open Banking</option>
                                <option value="M-Platform">M-Platform</option>
                                <option value="SAD">SAD</option>
                                <option value="Lombard">Lombard</option>
                            </Field>
                        </div>
                    </div>
                    <div>
                    <label htmlFor="employed">Brand</label>
                    <div>
                        <label className = "margin-forlable">
                        <Field
                            name="NWB"
                            id="NWB"
                            component="input"
                            type="checkbox"
                        /><span>NWB</span></label>
                         <label className = "margin-forlable">
                        <Field
                            name="RBS"
                            id="RBS"
                            component="input"
                            type="checkbox"
                        /><span>RBS</span></label>
                        <label className = "margin-forlable">
                        <Field
                            name="UBN"
                            id="UBN"
                            component="input"
                            type="checkbox"
                        /><span>UBN</span></label>
                        <label className = "margin-forlable">
                        <Field
                            name="URR"
                            id="URR"
                            component="input"
                            type="checkbox"
                        /><span>URR</span></label>
                    </div>
                </div>
                    <div>
                        <label>Date</label>
                        <div>
                            <Field name="datepicker" setDate = {this.scheduleDate} component = {datepicker} />
                        </div>
                    </div>
                    <div>
                        <label>FromTime</label>
                        <div>
                            <Field name="FromTime" component={TimeBlock} />
                        </div>
                    </div>
                    <div>
                        <label>ToTime</label>
                        <div>
                            <Field name="ToTime" component={TimeBlock} />
                        </div>
                    </div>
                    <div>
                        <label>Notes</label>
                        <div>
                            <Field name="notes" component="textarea" />
                        </div>
                    </div>
                    <div>
                        <label>Attachment</label>
                        <div>
                        <Field name="attachment" component={FileInput} type="file"/>
                        </div>
                    </div>
                    <div>
                        <button className = "button" type="submit" disabled={this.props.pristine || this.props.submitting}>Submit</button>
                        {/* <button  className = "button secondary" type="button" disabled={this.props.pristine || this.props.submitting} onClick={this.props.reset}>Clear Values</button> */}
                    </div>
                </form>
            );
        }
    }
    

    EnvBooking = reduxForm({
        form: 'EnvBooking', // a unique identifier for this form
        onSubmit: values => {
            window.alert("Submited: \n" + JSON.stringify(values, null, 2));
          }
    })(EnvBooking)

