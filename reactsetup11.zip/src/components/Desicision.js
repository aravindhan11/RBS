import React from "react";
import { dispatchData } from './DecisionData'
export default class SearchForm extends React.Component {
    constructor(props) {
        super(props);
        this.search = this.search.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleReject = this.handleReject.bind(this);
        this.radioChange = this.radioChange.bind(this);
        this.state = { text: "", data: null, reject:false, selectedOption: '',rejectReason:false };
    }

    handleReject(){
        this.setState({reject:true})
    }

    handleChange(event) {
        const newQuery = Object.freeze({ text: event.target.value });
        this.setState(newQuery);
    }

    radioChange(value){
        let reason = document.getElementById("reject");
        this.setState({rejectReason:reason.checked})
    }

    async search() {
        
        const query = await dispatchData(this.state.text)
        console.log("query", query)
        if (query) {
            console.log("query22", query)
            this.setState({ data: query })
        }else{
            this.setState({data:null})
        }
        //if (this.props.onSearch) this.props.onSearch(newQuery);

    }
    

    render() {

        return (
            <div>
            <form className="border form-header">
                {this.state.reject ? "": (<div><h2>Search Your Request</h2>
                <div>
                    <input
                        type="text"
                        placeholder = "Request ID"
                        onChange={this.handleChange}
                        value={this.state.text}
                    />
                    <button className = "search-Button" type="button" onClick={this.search}>
                        Search
                    </button>
                </div>
                
                {this.state.data != null || undefined ? this.state.data.map(data => (<div>
                    <div>
                        <label>First Name</label>
                        <div><input type=" text" value={data.FirstName} disabled/>
                        </div>
                    </div>
                    <div>
                        <label>Last Name</label>
                        <div><input type=" text" value={data.LastName} disabled/>
                        </div>
                    </div>
                    <div>
                        <label>Email</label>
                        <div><input type=" text" value={data.Email} disabled/>
                        </div>
                    </div>
                    <div>
                        <label>Environment</label>
                        <div><input type=" text" value={data.Environment} disabled/>
                        </div>
                    </div>
                    <div>
                        <label>Date</label>
                        <div><input type=" text" value={data.date} disabled/>
                        </div>
                    </div>
                    <div>
                        <label>Time</label>
                        <div><input type=" text" value={data.time} disabled/>
                        </div>
                    </div>
                    <div className = "approve-reject">
                        {/* <button className = "button" type="button" disabled={this.props.pristine || this.props.submitting}>Approve</button> */}
                        {/* <button  className = "button secondary" type="button" disabled={this.props.pristine || this.props.submitting} onClick={this.handleReject}>
                        Reject</button> */}
                        <label><input type="radio" id = "approve" name = "descision" value = "approve" onClick = {this.radioChange}/> Approve </label>
                        
                        <label><input className = "reject-button"type="radio" id = "reject" name = "descision" value = "reject" onClick = {this.radioChange}/> Reject</label>
                    </div>
                    {this.state.rejectReason ? (<div>
                    <label>Reject Reason:</label>
                    <div><input type="text" id="txtPassportNumber" />
                    </div></div>):""}
                    <button className = "decision-submit" type="button" onClick={this.search}>
                        Submit
                    </button>
                </div>)) : ""}</div>)}
            </form></div>
        );
    }
}
