import React from 'react';
import 'react-bootstrap'
import './Landing.scss';
//import Dashboard from './Dashboard'
import { library } from "@fortawesome/fontawesome-svg-core";
import { fab } from "@fortawesome/free-brands-svg-icons";
import { faCheckSquare, faCoffee } from "@fortawesome/free-solid-svg-icons";

library.add(fab, faCheckSquare, faCoffee);

function Landing() {
  return (
    <div className="App">
      <div className=" border App-header">
        <h1>RBS Environment Managemenent</h1>
        <p>
        The following dashboards bring together both recently fixed bugs and suggestions, as well as bugs that we're currently working on for Jira Software,Bitbucket.
        These dashboards can be used to plan your next upgrade, and include information about Enterprise Releases and fixes for our Data Center products as well.
        </p>
        {/* <div className="bd-exampl">
          <a href="/Dashboard" class="hyperlinkButton btn btn-outline-primary" role="button">Dashboard</a>
          <a href="/EnvBooking" class="hyperlinkButton btn btn-outline-primary" role="button">EnvBooking</a>
          <a href="/Desicision" class="hyperlinkButton btn btn-outline-primary" role="button">Desicision</a>
          <a href="/Audit" class="hyperlinkButton btn btn-outline-primary" role="button">Audit</a>
        </div> */}

        {/* <Link className = "App-link" type = "button" to = {'/Dashboard'}>Dashboard</Link> */}
      </div>
    </div>
  );
}

export default Landing;
