import React from 'react';

export const dispatchData = (query) => {
    console.log(query)
    const RBSProfile = [{
        FirstName: "Aravindhan",
        LastName: "Ravi",
        Email: "aravindhanr@gmail.com",
        Environment: "Dev",
        date: "11/11/2019",
        time: "10am - 12pm"
    }]
    

    if (query) {
        console.log("data2", query)
        return RBSProfile
    }
}
