import "rc-time-picker/assets/index.css";
import React from "react";
import TimePicker from "rc-time-picker";

export default class Test extends React.Component {
  constructor(props) {
    super(props);
    this.state = { min: 5, sec: 6 };
  }
  onChange = time => this.setState({ time })
  render() {
    
    return (
      <div>
        <TimePicker className = "react-clock"
          onChange={this.onChange}
          value={this.state.time}
        />
      </div>
    );
  }
}

