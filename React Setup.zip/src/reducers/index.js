import { combineReducers} from 'redux';
import mainReducer from './mainReducer';
import { reducer as form } from "redux-form";

const reducer = () => combineReducers({form})
export default reducer (
    {
        main : mainReducer
    }
)