import React from 'react';
import { slide as Menu } from 'react-burger-menu';
import './sidebar.scss'

export default props => {

  return (
    <nav className = "border border-light accordion">
                    <ul>
                    <li><a href="/Dashboard">Dashboard</a></li>
                    <li><a href="/EnvBooking">Booking</a></li>
                    <li><a href="/Audit">Audit</a></li>
                    <li><a href="/Desicision">Review</a></li>
                    </ul>
    </nav>
  );
};