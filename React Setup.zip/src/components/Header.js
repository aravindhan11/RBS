import React, { Component } from 'react';
import RBS from '../logos/RBSCOT.jpg';
//import "bootstrap/dist/css/bootstrap.css"

export default class Header extends Component {

    render() {
        return (
                <div class="w3-top width-top">
                    <div class="w3-bar w3-header w3-card">
                        <img className="image-rbs" src={RBS} alt="RBS" />

                        <div class="w3-right w3-hide-small">
                            <a href="/" class="w3-bar-item w3-button">Home</a>
                            <a href="#contact" class="w3-bar-item w3-button">FAQ's</a>
                        </div>
                    </div>
                </div>

        );

    }

}