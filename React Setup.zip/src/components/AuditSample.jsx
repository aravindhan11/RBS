import React, { Component } from "react";
import matchSorter from 'match-sorter';

// Import React Table
import ReactTable from "react-table";
import "react-table/react-table.css";
import FilledForms from "./FilledForms";


export default class AuditSample extends Component {
  constructor() {
    super();
    this.state = {
      data: "", showModal: false, formData: ""
    };
    this.handleEdit = this.handleEdit.bind(this);
  }

  handleEdit(data) {
    this.setState({ showModal: true, formData: data })
  }
  closeModal() {
    this.setState({ showModal: false });
  }
  render() {

    let { data } = this.state;
    data = [
      {
        EmpName: "Aravin",
        Email:"aravin@rbos.co.uk",
        Status: "Approved",
        Date: "12/8/19",
        FromTime: "11:00:00",
        ToTime: "11:50:00",
        Client: "M-Platform",
        Environment: "SIT",
        Brand: "NWB,RBS"

      },
      {
        EmpName: "Madav",
        Email:"madav@rbos.co.uk",
        Status: "Pending",
        Date: "13/8/19",
        FromTime: "10:00:00",
        ToTime: "10:50:00",
        Client: "Lombard",
        Environment: "NFT",
        Brand: "UBN,URR"

      },
      {
        EmpName: "Ben",
        Email:"ben@rbos.co.uk",
        Status: "Pending",
        Date: "14/8/19",
        FromTime: "12:00:00",
        ToTime: "12:50:00",
        Client: "Open Banking",
        Environment: "DEV",
        Brand: "RBS,UBN"

      },
    ]
    return (
      <div>
        <h2>Audit</h2>
        {this.state.showModal ? <FilledForms requestorDetails={this.state.formData} /> : <ReactTable
          data={data}
          filterable
          defaultFilterMethod={(filter, row) =>
            String(row[filter.id]) === filter.value}
          columns={[
            {
              Header: "",
              columns: [
                {
                  Header: 'Action',
                  Cell: row => (
                    <button onClick={() => this.handleEdit(row.original)}>Edit</button>
                  )
                },
                {
                  Header: "Name",
                  accessor: "EmpName",
                  filterMethod: (filter, rows) =>
                    matchSorter(rows, filter.value, { keys: ["EmpName"] }),
                  filterAll: true,

                },

              ]
            },
            {
              Header: "Info",
              columns: [
                {
                  Header: "Client",
                  accessor: "Client",
                  filterMethod: (filter, rows) =>
                    matchSorter(rows, filter.value, { keys: ["Client"] }),
                  filterAll: true
                },
                {
                  Header: "Environment",
                  accessor: "Environment",
                  filterMethod: (filter, rows) =>
                    matchSorter(rows, filter.value, { keys: ["Environment"] }),
                  filterAll: true
                },
                {
                  Header: "Brand",
                  accessor: "Brand",
                  filterMethod: (filter, rows) =>
                    matchSorter(rows, filter.value, { keys: ["Brand"] }),
                  filterAll: true
                }
              ]},
            {
              Header: "Scheduled Time",
              columns: [
                {
                  Header: "Date",
                  accessor: "Date",
                  filterMethod: (filter, rows) =>
                    matchSorter(rows, filter.value, { keys: ["Date"] }),
                  filterAll: true,
                },
                {
                  Header: "From-Time",
                  accessor: "FromTime",
                  filterMethod: (filter, rows) =>
                    matchSorter(rows, filter.value, { keys: ["FromTime"] }),
                  filterAll: true,
                },
                {
                  Header: "To-Time",
                  accessor: "ToTime",
                  filterMethod: (filter, rows) =>
                    matchSorter(rows, filter.value, { keys: ["ToTime"] }),
                  filterAll: true,
                }
              ]
            },
            {
                  Header: "Status",
                  accessor: "Status",
                  id: "Status",
                  filterMethod: (filter, row) => {
                    console.log("vluae", filter, row)
                    if (filter.value === "all") {
                      return true;
                    }
                    if (filter.value === "Approved") {
                      return row[filter.id] === "Approved"
                    }
                    return row[filter.id] === "Pending"
                  },
                  Filter: ({ filter, onChange }) =>
                    <select
                      onChange={event => onChange(event.target.value)}
                      style={{ width: "100%" }}
                      value={filter ? filter.value : "Show All"}

                    >
                      <option value="all">Show All</option>
                      <option value="Approved">Approved</option>
                      <option value="Pending">Pending</option>
                    </select>
                }
              ]
            }
          defaultPageSize={10}
          className="-striped -highlight"
        />}
      </div>

    );
  }
}

