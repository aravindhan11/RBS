import React from 'react';
import {BrowserRouter, Route} from 'react-router-dom';
import Landing from './Landing';
import Dashboard from './Dashboard';
import EnvBooking from './EnvBooking';
import Desicison from './Desicision';
import Audit from './AuditSample';
import Header from './Header';
import Footer from './Footer';
import './main.scss'
import Sidebar from './Sidebar';

const App = () => {

    return(

        <div>
            <BrowserRouter>
            <Header/>
            <div>
                <section>
                <Sidebar />
                <article>
                <Route exact path = "/" component = {Landing} />
                <Route path = "/Dashboard" component = {Dashboard} />
                <Route path = "/EnvBooking" component = {EnvBooking} />
                <Route path = "/Desicision" component = {Desicison} />
                <Route path = "/Audit" component = {Audit} />
                <div class="push"></div>
                </article>
                </section>
            </div>
            <Footer/>
            </BrowserRouter>
        </div>
    );
}

export default App;