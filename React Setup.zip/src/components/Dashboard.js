import React from 'react';
//import Scheduler, { SchedulerData, ViewTypes, DATE_FORMAT } from 'react-big-scheduler'
//import 'react-big-scheduler/lib/css/style.css'
import {Calendar, momentLocalizer} from 'react-big-calendar'
import './calendar.scss';
import moment from 'moment'

// moment.locale('en-GB');
const localizer = momentLocalizer(moment)

const Dashboard = () => {

    return (<div className = "main-header">
        <h2>Dashboard</h2>
        <Calendar
            localizer={localizer}
            events={[
                {
                    'title': 'My event',
                    'allDay': false,
                    'start': new Date(2019, 6, 25, 10, 0), // 10.00 AM
                    'end': new Date(2019, 6, 25, 14, 0), // 2.00 PM 
                }
            ]}
            step={60}
            // view='week'
            // views={['week']}
            // min={new Date(2008, 0, 1, 8, 0)} // 8.00 AM
            // max={new Date(2008, 0, 1, 17, 0)} // Max will be 6.00 PM!
            //date={new Date(2018, 0, 1)}
            startAccessor="start"
            endAccessor="end"
        />
    </div>
    )

}



export default Dashboard
